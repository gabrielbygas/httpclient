#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>

int socket_connect(char *host, in_port_t port){ //supprimer
    int sock;
    struct hostent *hp;
    struct sockaddr_in serv_addr;
    struct sockaddr_in addr;

    if ((hp = gethostbyname(host)) == NULL)
    { // take the IP addr
        herror("gethostbyname");
        exit(1);
    }

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    inet_aton(hp, &serv_addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        printf("\nConnection Failed \n");
        return -1;
    }
    return sock;
}

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]){
    char buffer[BUFFER_SIZE];
    char *shost = NULL, *surl = NULL, *surname = NULL, *sfile = NULL;
    char *sport = NULL, *saddr = NULL, *sget = NULL, *shead = NULL, *sput = NULL;
    int c, ret;
    int ssport;
    char request[100], scaddr[50];
    FILE *ofp;
    int pfile = 0;
    int method = 0;

    int sock = 0;

    if (argc < 3)
    { // a analyser
        fprintf(stderr, "Usage: %s <hostname> <port>\n", argv[0]);
        exit(1);
    }

    while((c = getopt(argc, argv, "c:u:a:p:g:o:h:t:d:")) != -1)
    switch (c)
    {
        case 'c':
            saddr = optarg;
            sprintf(scaddr, "%s", saddr);
            sport = strstr(scaddr, ":");
            sport = sport+1;
            strtok(saddr,":");
            ssport = atoi(sport);
            break;
        case 'u':
            surl = optarg;
            break;
        case 'a':
            surname = optarg;
            break;
        case 'd':
            sget = optarg;
            method = 2;
            break;
        case 'g':
            sget = optarg;
            method = 1;
            break;
        case 't':
            sput = optarg;
            method = 3;
            break;
        case 'o':
            sfile = optarg;
            ofp = fopen(sfile, "w");
            pfile = 1;
            break;
        case 'h':
            shead = optarg;
            break;
        case '?':
            fprintf(stderr, "Unrecognized option: -%c\n", optopt);
            return 1;
        default:
            abort();
    }

    /////////////////////////////////////////////
    sock = socket_connect(saddr, ssport);
    ///////////////////////////////////////////////

    switch (method)
    {
    case 1:
        sprintf(request, "GET /%s?%s HTTP/1.1\r\nHost:%s\r\n%s\r\n\r\n", surl, sget, saddr, shead);
        break;
    case 2:
        sprintf(request, "POST /%s HTTP/1.1\r\nHost:%s\r\n%s\r\n\r\n%s", surl, saddr, shead, sget);
        break;
    case 3:
        sprintf(request, "PUT /%s HTTP/1.1\r\nHost:%s\r\nContent-Type: plain/text\r\n%s\r\n\r\n", sput, saddr, shead);
        break;
    default:
        sprintf(request, "GET /%s?%s HTTP/1.1\r\nHost:%s\r\nX-FirstName:%s\r\n\r\n", surl, sget, saddr, shead);
    }

    write(sock, request, strlen(request));
    bzero(buffer, BUFFER_SIZE); // reset buffer

    if (pfile == 1){
        if (ofp == NULL)
        {
            fprintf(stderr, "Can't open output file %s!\n",
                    sfile);
            exit(1); // if file doesnt exist
        }
    }

    while (read(sock, buffer, BUFFER_SIZE - 1) != 0){

        if (pfile == 1)
        {
            fprintf(ofp, buffer); //write to file
        }
        else
        {
            fprintf(stderr, "%s", buffer);
        }

        bzero(buffer, BUFFER_SIZE);
    }

    if (pfile == 1){
        fclose(ofp);
    }
    else{
        printf("%s\n", stderr);
    }
    close(sock); //close file
    return 0;
}
